import React from "react";
import Customers from "./components/Customers";
import Appointments from "./components/Appointments";
import ReminderWatcher from "./components/ReminderWatcher";
import config from "./config";

function App() {
  return (
    <div>
      <h1>{config.appTitle}</h1>
      <Customers />
      <Appointments />
      <ReminderWatcher />
    </div>
  );
}

export default App;
