const config = {
  appTitle: "CRM Projesi",
  menus: {
    customers: "Müşteriler",
    appointments: "Randevular"
  },
  customerFields: {
    name: "Ad",
    surname: "Soyad",
    phone: "Telefon"
  },
  appointmentFields: {
    title: "Başlık",
    date: "Tarih"
  }
};

export default config;
