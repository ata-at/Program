import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB-3JbqPlAFJVBq4AcXtNnxTkIey3E4jV0",
  authDomain: "crmproje-4d0ce.firebaseapp.com",
  projectId: "crmproje-4d0ce",
  storageBucket: "crmproje-4d0ce.appspot.com",
  messagingSenderId: "981706919220",
  appId: "1:981706919220:web:591fc9b42f02e0aa13e961",
  measurementId: "G-WKQZ3J675S"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
