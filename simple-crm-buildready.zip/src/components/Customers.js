import React, { useState, useEffect } from "react";
import { collection, addDoc, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";
import config from "../config";

function Customers() {
  const [name, setName] = useState("");
  const [surname, setSurname] = useState("");
  const [phone, setPhone] = useState("");
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "customers"), (snapshot) => {
      setCustomers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const addCustomer = async () => {
    if (!name || !surname || !phone) return;
    await addDoc(collection(db, "customers"), { name, surname, phone });
    setName("");
    setSurname("");
    setPhone("");
  };

  return (
    <div>
      <h2>{config.menus.customers}</h2>
      <input placeholder={config.customerFields.name} value={name} onChange={e => setName(e.target.value)} />
      <input placeholder={config.customerFields.surname} value={surname} onChange={e => setSurname(e.target.value)} />
      <input placeholder={config.customerFields.phone} value={phone} onChange={e => setPhone(e.target.value)} />
      <button onClick={addCustomer}>Ekle</button>
      <ul>
        {customers.map(c => (
          <li key={c.id}>{c.name} {c.surname} - {c.phone}</li>
        ))}
      </ul>
    </div>
  );
}

export default Customers;
