import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";
import { useEffect } from "react";

function ReminderWatcher() {
  useEffect(() => {
    if (Notification.permission !== "granted") {
      Notification.requestPermission();
    }

    const unsub = onSnapshot(collection(db, "appointments"), (snapshot) => {
      const now = new Date().getTime();
      snapshot.forEach(doc => {
        const data = doc.data();
        if (data.start) {
          const startTime = data.start.toDate ? data.start.toDate().getTime() : new Date(data.start.seconds*1000).getTime();
          if (startTime - now < 10 * 60 * 1000 && startTime > now) {
            new Notification("Yaklaşan Randevu", { body: data.title });
          }
        }
      });
    });
    return () => unsub();
  }, []);

  return null;
}

export default ReminderWatcher;
