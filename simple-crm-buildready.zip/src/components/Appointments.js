import React, { useState, useEffect } from "react";
import { collection, addDoc, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";
import config from "../config";

function Appointments() {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "appointments"), (snapshot) => {
      setAppointments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const addAppointment = async () => {
    if (!title || !date) return;
    await addDoc(collection(db, "appointments"), {
      title,
      start: new Date(date)
    });
    setTitle("");
    setDate("");
  };

  return (
    <div>
      <h2>{config.menus.appointments}</h2>
      <input placeholder={config.appointmentFields.title} value={title} onChange={e => setTitle(e.target.value)} />
      <input type="datetime-local" value={date} onChange={e => setDate(e.target.value)} />
      <button onClick={addAppointment}>Ekle</button>
      <ul>
        {appointments.map(a => (
          <li key={a.id}>
            {a.title} - {a.start.toDate ? a.start.toDate().toLocaleString() : new Date(a.start.seconds*1000).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Appointments;
